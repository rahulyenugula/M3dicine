package com.example.android.bluetoothlegatt;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.widget.Button;
import android.widget.TextView;


import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;

import java.util.Arrays;
import java.util.List;
import java.util.Random;


public class GraphViewControl extends Activity  {
    private final Handler mHandler = new Handler();
    private Runnable mTimer;
    private double graphLastXValue = 5d;
   // private LineGraphSeries<DataPoint> mSeries;
    private static final Random rand = new Random();
  //  private LineGraphSeries<DataPoint> series;
    public double y_axis;

//EditText editText,editText1;
Button button1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.streaming);
       TextView textView = (TextView) findViewById(R.id.textview1);
        Bundle b = getIntent().getExtras();
        String received = b.getString("value");
//String[]k=received.split("\n",5);
        List<String> myList = new ArrayList<String>(Arrays.asList(received.split("0A",5)));
        ArrayList<String> stream1 = new ArrayList<>();

stream1.add(String.valueOf(myList));
//System.out.print(myList.get(0));
//textView.append((CharSequence) myList);
//textView.append(myList.get(0));
        textView.setMovementMethod(new ScrollingMovementMethod());

        if(stream1.size()>0) {
            GraphView graphView = (GraphView) findViewById(R.id.graph);
            LineGraphSeries<DataPoint> series = new LineGraphSeries();
            for(int i =0;i<stream1.size();i++){

            }
            graphView.addSeries(series);

        }


    }

      /*  Button button = (Button) findViewById(R.id.buttoni);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backActivity();
            }
        });*/
       //GraphView graphView = (GraphView) findViewById(R.id.graph);



}


        /*   DataPoint[] dataPoints = new DataPoint[stream1.size()]; // declare an array of DataPoint objects with the same size as your list
        for (int i = 0; i < stream1.size(); i++) {
            // add new DataPoint object to the array for each of your list entries
            dataPoints[i] = new DataPoint(i, stream1.s); // not sure but I think the second argument should be of type double
        }
graphView.addSeries(series);*/





         /*   public void backActivity () {
            Intent intent1 = new Intent(this, DeviceControlActivity.class);
            startActivity(intent1);

        }*/



































































