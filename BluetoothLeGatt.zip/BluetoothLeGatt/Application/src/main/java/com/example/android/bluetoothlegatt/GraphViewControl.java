package com.example.android.bluetoothlegatt;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;



import java.util.ArrayList;

import java.util.Random;



public class GraphViewControl extends Activity {
    private static final Random rand = new Random();
  //  private LineGraphSeries<DataPoint> series;
    public double y_axis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.streaming);
        TextView textView = (TextView) findViewById(R.id.textview1);
        Bundle b = getIntent().getExtras();
        String received = b.getString("value");
        textView.setText(received);
        ArrayList<String> stream1 = new ArrayList<>();
/*y_axis = Double.parseDouble(received);*/

        stream1.add(received);
        textView.append(received);

        textView.setMovementMethod(new ScrollingMovementMethod());
        Button button = (Button) findViewById(R.id.buttoni);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backActivity();
            }
        });
        GraphView graphView = (GraphView) findViewById(R.id.graph);
LineGraphSeries<DataPoint> series=new LineGraphSeries<DataPoint>();

     for (int x = 0; x < 90; x++) {
            double y = Math.sin(x);

            series.appendData(new DataPoint(x, y), true, 90);

        }
        graphView.addSeries(series);
/*if(stream1.size()>0){
    LineGraphSeries<DataPoint>   series = new LineGraphSeries<DataPoint>();
    for(int i=0;i<stream1.size();i++){
        DataPoint point=new DataPoint(i, Double.parseDouble(stream1.get(i)));
        series.appendData(point,true,stream1.size());
    }
    graphView.addSeries(series);
}*/

     /*   DataPoint[] dataPoints = new DataPoint[stream1.size()]; // declare an array of DataPoint objects with the same size as your list
        for (int i = 0; i < stream1.size(); i++) {
            // add new DataPoint object to the array for each of your list entries
            dataPoints[i] = new DataPoint(i, stream1.indexOf(dataPoints)); // not sure but I think the second argument should be of type double
        }
graphView.addSeries(series);*/

    }

        public void backActivity () {
            Intent intent1 = new Intent(this, DeviceControlActivity.class);
            startActivity(intent1);
        }
    }


































































