package com.example.StetheePro;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;

public class SimpleDividerItemDecoration extends RecyclerView.ItemDecoration {
    public SimpleDividerItemDecoration(Context mContext) {
    }
}
