package com.example.StetheePro;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.Set;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int PERMISSION_ALL = 1;
   // private final String[] PERMISSIONS = {Manifest.permission.ACCESS_FINE_LOCATION};

    private static final int REQUEST_ENABLE_BT = 0;
    private static final int REQUEST_DISCOVER_BT = 1;
    private TextView mStatusBleTv, mPairedTv, mscanTV;
    private Context mContext;
    private ArrayList<BLEdevice> availableList;
    Button mOnBtn;
    Button mOffBtn;
    Button mDiscoverBtn;
    Button mPairedBtn;

    private RecyclerView devicesListView;
    private LeDeviceListAdaptor availableDeviceAdapter;
    private BluetoothAdapter mBtAdaptor;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = getApplicationContext();
        availableList = new ArrayList<>();

        mStatusBleTv = findViewById(R.id.statusBluetoothTv);
        mPairedTv = findViewById(R.id.pairTv);
        mOnBtn = findViewById(R.id.onButn);
        mOffBtn = findViewById(R.id.offButn);
        mDiscoverBtn = findViewById(R.id.discoverableBtn);
        mPairedBtn = findViewById(R.id.PairedBtn);
        devicesListView = findViewById(R.id.devicesListView);
        devicesListView.setHasFixedSize(true);
        LinearLayoutManager lManager = new LinearLayoutManager(mContext);
        lManager.setOrientation(LinearLayoutManager.VERTICAL);
        devicesListView.setLayoutManager(lManager);
        devicesListView.addItemDecoration(new SimpleDividerItemDecoration(mContext));


        // Initializes Bluetooth adapter.
        final BluetoothManager bluetoothmanager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBtAdaptor = bluetoothmanager.getAdapter();
        if (mBtAdaptor == null) {
            mStatusBleTv.setText("Bluetooth is not available");
        } else {
            mStatusBleTv.setText("Bluetooth is  available");


//Turn on Bluetooth
            mOnBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!mBtAdaptor.isEnabled()) {
                        showToast("Turning on Bluetooth..");
                        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivityForResult(intent, REQUEST_ENABLE_BT);
                    } else {
                        showToast("Bluetooth is already on");
                    }
                }
            });
// Make device discoverable
            mDiscoverBtn.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (!mBtAdaptor.isDiscovering()) {
                        showToast("Making Your Device Discoverable");
                        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                        startActivityForResult(intent, REQUEST_DISCOVER_BT);
                    }
                }
            });
//Turn off bluetooth
            mOffBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mBtAdaptor.isEnabled()) {
                        mBtAdaptor.disable();
                        showToast("Turning  Bluetooth off");

                    } else {
                        showToast("Bluetooth is already off");

                    }
                }
            });


//Show paired devices
            mPairedBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (mBtAdaptor.isEnabled()) {
                        mPairedTv.setText("Paired Devices");

                        Set<BluetoothDevice> devices = mBtAdaptor.getBondedDevices();

                        for (BluetoothDevice device : devices) {
                            mPairedTv.append("\n Device : " + device.getName() + " , " + device);

                        }
                    } else {
                        showToast("Turn On bluetooth to get paired devices");
                    }
                }
            });
        }

        Button btnScan = findViewById(R.id.btnScan);
//Scan for Bluetooth low energy devices
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scan();

            }

            private void scan() {
                if (mBtAdaptor == null)
                    return;

                BluetoothLeScanner scanner;
                scanner = mBtAdaptor.getBluetoothLeScanner();
                if (scanner != null) {
                    scanner.startScan(scanCallback);
                    Log.d(TAG, "scan started");
                } else {
                    Log.e(TAG, "could not get scanner object");
                }
            }

            private ScanCallback scanCallback =
                    new ScanCallback() {
                        @Override
                        public void onScanResult(int callbackType, ScanResult result) {
                            super.onScanResult(callbackType, result);

                            BluetoothDevice device = result.getDevice();
                            int newRssi = result.getRssi();
                            String name = device.getName();

                            if (name == null || name.isEmpty()) {
                                name = "Unknown Device";
                            }

                            boolean isDeviceAdded = false;

                            if (availableList != null) {
                                for (BLEdevice d : availableList) {
                                    if (d.getAddress().equalsIgnoreCase(device.getAddress())) {
                                        isDeviceAdded = true;
                                        d.setName(name);
                                        d.setRssi(newRssi);
                                    }
                                }
                            }

                            if (!isDeviceAdded)
                                availableList.add(new BLEdevice(name, device.getAddress(), newRssi));

                            populateAvailableDevices();
                        }
                    };


            private void populateAvailableDevices() {
                availableDeviceAdapter = new LeDeviceListAdaptor(availableList, new LeDeviceListAdaptor.OnDeviceClickListener() {
                    @Override
                    public void onDeviceClick(int position) {

                    }
                });

                devicesListView.setAdapter(availableDeviceAdapter);
                devicesListView.invalidate();
            }


        });
    }


    public void Press(View view) {
        class SimpleDividerItemDecoration extends RecyclerView.ItemDecoration {
            private Drawable mDivider;

            public SimpleDividerItemDecoration(Context context) {
                mDivider = ContextCompat.getDrawable(context, R.drawable.line_divider);
            }

            @Override
            public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
                int left = parent.getPaddingLeft();
                int right = parent.getWidth() - parent.getPaddingRight();

                int childCount = parent.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View child = parent.getChildAt(i);

                    RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child.getLayoutParams();

                    int top = child.getBottom() + params.bottomMargin;
                    int bottom = top + mDivider.getIntrinsicHeight();

                    mDivider.setBounds(left, top, right, bottom);
                    mDivider.draw(c);
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        switch (requestCode) {
            case REQUEST_ENABLE_BT:
                if (resultCode == RESULT_OK) {

                    showToast("Bluetooth is On");
                } else {
                    showToast("Bluetooth is Off");

                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);

    }

    private void showToast(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}