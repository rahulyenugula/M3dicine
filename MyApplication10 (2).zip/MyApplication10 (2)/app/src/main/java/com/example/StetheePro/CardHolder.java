package com.example.StetheePro;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

    public class CardHolder extends RecyclerView.ViewHolder{

        private TextView txtDeviceName, txtMACAddress, txtRssi;

        public CardHolder(View itemView) {
            super(itemView);
            this.txtDeviceName = itemView.findViewById(R.id.txtDeviceName);
            this.txtRssi = itemView.findViewById(R.id.txtRssi);
            this.txtMACAddress = itemView.findViewById(R.id.txtMACAddress);
        }

        public void updateUI(final BLEdevice device) {

            txtDeviceName.setText(device.getName());
            txtMACAddress.setText(device.getAddress());
            txtRssi.setText(String.valueOf(device.getRssi()) + " dBm");
        }
    }
