package com.example.StetheePro;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

    public class LeDeviceListAdaptor extends RecyclerView.Adapter<CardHolder> {

        public interface OnDeviceClickListener {
            void onDeviceClick(int position);
        }

        private ArrayList<BLEdevice> devices;
        private OnDeviceClickListener listener;

        public LeDeviceListAdaptor(ArrayList<BLEdevice> devices, OnDeviceClickListener listener) {
            this.devices = devices;
            this.listener = listener;
        }

        @Override
        public void onBindViewHolder(final CardHolder holder, final int position) {
            final BLEdevice device = devices.get(position);
            holder.updateUI(device);

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onDeviceClick(position);
                }
            });
        }

        @Override
        public int getItemCount() {
            return devices.size();
        }



        @Override
        public CardHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View deviceCard = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_device, parent, false);
            return new CardHolder(deviceCard);
        }

    }

